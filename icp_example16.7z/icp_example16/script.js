const formElement = document.querySelector('.form'); 
formElement.addEventListener('submit', (e) => {
  e.preventDefault();
  // Получаем данные
  const checkName = document.querySelector('.name').value;
  const checkEmail = document.querySelector('.email').value
  const checkFio = document.querySelector('.fio').value;
  const checkKomment = document.querySelector('.komment').value;
  const formText = document.querySelector('.form_text')
  const localText = document.querySelector('.local_text')
  const textdanger = document.querySelector('.text')
  const textdangerEmail = document.querySelector(".email_danger")
  const textdangerFio = document.querySelector(".fio_danger")
  const textdangerComment = document.querySelector(".comment_danger")
  const textdangerName = document.querySelector(".name_danger")

  formText.textContent = `Фио: ${checkName} Почта : ${checkEmail} Фамилия : ${checkFio} Комментарий :  ${checkKomment}`;
 // Запись в хранилище

 document.cookie = `name=${checkName};`
 document.cookie = `email=${checkEmail}`
 document.cookie = `fio=${checkFio}`
 document.cookie = `comment=${checkKomment}`
  // проверка на пустые поля

  if (checkName === "" && checkEmail === "" && checkFio == "" && checkKomment == "" ) {
    textdanger.textContent = "Все поля пустые"
  }
  else if (checkName === "") {
    textdangerName.textContent = "Поле имя пустое"
  }
  else if (checkFio === "") {
    textdangerFio.textContent = "Поле фамилия пустое"
  }
  else if (checkEmail === "") {
    textdangerEmail.textContent = "Поле почта пустое"
  }
  else if (checkKomment === "") {
    textdangerComment.textContent = "Поле комментарий пустое"
  }

  else {
    textdangerName.textContent = ""
    textdangerEmail.textContent = ""
    textdangerFio.textContent = ""
    textdangerComment.textContent = ""
    textdanger.textContent = ""
    textdanger.textContent = "Все поля заполнены"
  }

  //JSON формат
  let doc = {
    name : checkName,
    email : checkEmail,
    fio : checkFio,
    comment : checkKomment
  }
  let doc_parse = JSON.stringify(doc);

  alert(doc_parse)
});

// Валидация почты
function Validate() {
  let regexp = /^[\w\d%$:.-]+@\w+\.\w{2,5}$/;
  let str = document.querySelector(".email").value;
  let email = document.querySelector(".text_email")
  if (!regexp.test(str)) {
    email.textContent = "Не верные данные"
  }
  else {
    email.textContent = "Все верно"
  }
}


$(document).ready(function(){
  var selected = document.cookie.match(/select=(.+?);/);
  if (selected) {
    $('#example').val(selected);
  }

  $('#example').change(function(){
    document.cookie = "select=" + $(this).val();
  });
});
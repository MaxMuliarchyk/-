function math() {
  let d = prompt("Введите радиус окружности: ");
  return 2 * Math.PI * d;
}

document.writeln(math());

let s1 = "Я люблю Беларусь";
let s2 = "Я учусь в Политехническом колледже";

document.write("<br>" + "Длина строки s1: " + s1.length);

for (let i = 1; i <= s1.length; i++) {
  if (i == 9) {
    document.write("<br>" + "Найденный символ: " + s1[i]);
    document.write("<br>" + "ASCII - код равен " + s1[i].charCodeAt(0));
  }
}
Replacetext = s2.split("о").join("а");
document.write("<br>" + "Итоговый измененный текст: " + Replacetext);

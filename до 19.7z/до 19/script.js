//----------
//ООП подход
//----------

class User { //Класс ООП
    constructor(name) {
      this.name = name;
    }
    age;
  
    nameOf() {
        return this.name;
    }
 }
  
const user = new User();
user.name = "Влад";
user.age = "19";
console.log(user.nameOf());

function startup() {
  var el = document.getElementById("canvas");
  el.addEventListener("touchstart", handleStart, false);
  el.addEventListener("touchend", handleEnd, false);
  el.addEventListener("touchcancel", handleCancel, false);
  el.addEventListener("touchmove", handleMove, false);
}

window.addEventListener('load', function(){ // после загрузки страницы
  document.body.addEventListener('touchstart', function(e){
      alert(e.changedTouches[0].pageX) // показ коррдинат места прикосновения по X-у.
  }, false)
}, false)